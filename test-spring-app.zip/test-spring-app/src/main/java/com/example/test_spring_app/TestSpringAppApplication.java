package com.example.test_spring_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSpringAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSpringAppApplication.class, args);
	}

}
